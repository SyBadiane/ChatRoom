package org.esp.dic3.messenger.client.salon1;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;
import org.apache.xmlrpc.client.XmlRpcCommonsTransportFactory;



public class MyXmlRpcClient {
	XmlRpcClient client=null;
	
	public MyXmlRpcClient (String server) {
		 XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
		    try {
				config.setServerURL(new URL(server));
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    client = new XmlRpcClient();
		    client.setTransportFactory(new XmlRpcCommonsTransportFactory(client));
		    client.setConfig(config);
	}
	
	public String inscription(String pseudo) throws XmlRpcException
	{
		Object[] params = new Object[]{pseudo};
		
		String result = (String) client.execute("Chat.subscribe", params);
		
		return result;
	}
	
	
	public String deconnexion(String pseudo) throws XmlRpcException
	{
		Object[] params = new Object[]{pseudo};
		
		String result = (String) client.execute("Chat.unsubscribe", params);
		
		return result;
	}
	
	public String envoyerMessage(String pseudo,String message) throws XmlRpcException
	{
		Object[] params = new Object[]{pseudo,message};
		
		String result = (String) client.execute("Chat.sendMessage", params);
		
		return result;
	}
	
	
	public List <Message> recupererMessage(String pseudo) throws XmlRpcException
	{
		Object[] params = new Object[]{pseudo};
		
		Object[] result =(Object[]) client.execute("Chat.newMessages", params);
		List<Message> messages = new ArrayList<Message>();
		Object[] userSender=(Object[])result[0];
		Object[] messagesRcu=(Object[])result[1];
		int taille=	messagesRcu.length;
		if(taille==0)
			return null;
		
		for (int i = 0; i < taille; i++) {
			messages.add(new Message((String)userSender[i],(String)messagesRcu[i]));
		}
		
		return messages;
	}
	
	
	public List <String> recupererUsers(String pseudo) throws XmlRpcException
	{
		Object[] params = new Object[]{pseudo};
		List<String> users=new ArrayList<String>();
		
		Object[] result =(Object[]) client.execute("Chat.newUsers", params);
		int taille=result.length;
		for (int i = 0; i <taille ; i++) {
			users.add((String)result[i]);
		}
		
		if(taille!=0)
		return users;
		else
			return null;
	}
	
	
	
	


}
