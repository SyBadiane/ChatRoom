package org.esp.dic3.messenger.testsend;

public class para {
	
	 private   String  name;

	    
	 private	  String email;

	 private   String message;

	 public int salon;
	 
	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }

	    public String getMessage() {
	        return message;
	    }

	    public void setMessage(String message) {
	        this.message = message;
	    }
		
		public para()
		{}	
	  public para(String name,String message,int salon) {
			super();
			this.name = name;
			
			this.salon=salon;
			this.message = message;
		}
	  
	  
	  public para(String name) {
	        this.name = name;
	    }
	  
	  public para(String name,int salon) {
	        this.name = name;
	        this.salon=salon;
	    }
	    
	  
	  
	//  public String toString()
	//  {
//		  return "name:"+name;
	//  }
	}
