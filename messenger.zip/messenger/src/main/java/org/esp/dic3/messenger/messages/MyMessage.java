package org.esp.dic3.messenger.messages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.xmlrpc.XmlRpcException;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.esp.dic3.messenger.client.salon1.Message;
import org.esp.dic3.messenger.client.salon1.MyXmlRpcClient;
import org.esp.dic3.messenger.client.salon1.Profile;
import org.esp.dic3.messenger.testsend.para;

import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;
import org.apache.xmlrpc.client.XmlRpcCommonsTransportFactory;


import com.sun.research.ws.wadl.Request;

@Path("message")
public class MyMessage {
	    @Context
	    UriInfo uriInfo;
	    @Context
	    Request request;
	    
	    private String salon1;
	    private String salon2;
	    private String salon3;
	    
	    
	    
	    
	public String getSalon1() {
			return salon1;
		}

		public void setSalon1(String salon1) {
			this.salon1 = salon1;
		}

		public String getSalon2() {
			return salon2;
		}

		public void setSalon2(String salon2) {
			this.salon2 = salon2;
		}

		public String getSalon3() {
			return salon3;
		}

		public void setSalon3(String salon3) {
			this.salon3 = salon3;
		}

		
		
	public MyMessage() {
		Properties prop = new Properties();
		/* Ici le fichier contenant les données de configuration est nommé 'ssInfos.myproperties' */
		 InputStream in=null;
		
		try {
			  in = this.getClass().getResourceAsStream("ssInfos.properties");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		try {
			prop.load(in);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Extraction des propriétés
		this.salon1= prop.getProperty("salon1");
		this.salon2= prop.getProperty("salon2");
		this.salon3= prop.getProperty("salon3");
	
			
		}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getMessage()
	{
		return "DALALA DIAM !!! ";
	}
	
	@POST
	@Path("postMessage")
	@Consumes(MediaType.APPLICATION_JSON )
	@Produces(MediaType.APPLICATION_JSON)
	public Response postMessage(para send) 
	{   
		int salon=send.salon;
		String response = null;
        MyXmlRpcClient clientSS=null;
		
		switch (salon) {
		case 1:
			clientSS=new MyXmlRpcClient(this.salon1);
			break;
		case 2:
			clientSS=new MyXmlRpcClient(this.salon2);
			break;	

		case 3:
			clientSS=new MyXmlRpcClient(this.salon3);
			break;	
		default:
			break;
		}
		
		
		
		    String result=new String();
			try {
				result = clientSS.envoyerMessage(send.getName(),send.getMessage());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		      
//		ObjectMapper jsonConvert = new ObjectMapper();
//		try {
//	        response= jsonConvert.writeValueAsString(send);
//		 } catch (Exception e) {
//	         
//	         e.printStackTrace();
//	     } 
		      
		 response=result;    
	     System.out.println("well done sendMess !!!");
		return Response.ok(response).build(); 
	}
	
//Pour s'inscrire sur un chat 
//Para contient le pseudo de l'utilisateur et le salon sur le quel il veut se connecter 
	
	@POST
	@Path("/inscription")
	@Consumes(MediaType.APPLICATION_JSON )
	@Produces(MediaType.APPLICATION_JSON)
	public Response postInscription(para send) 
	{  
		
		int salon=send.salon;
		String response = null;
		MyXmlRpcClient clientSS=null;
		
		switch (salon) {
		case 1:
			clientSS=new MyXmlRpcClient(this.salon1);
			break;
		case 2:
			clientSS=new MyXmlRpcClient(this.salon2);
			break;	

		case 3:
			clientSS=new MyXmlRpcClient(this.salon3);
			break;	
		default:
			break;
		}
		
		
	
		
		    String result=new String();
		    
		    
			try {
				result = clientSS.inscription(send.getName());
				response=result; 
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		      
			
		        
	     System.out.println("well done inscrip!");
		return Response.ok(response).build(); 
	}
	
//Se deconnecter d'un chat 
	
	@POST
	@Path("deconnecter")
	@Consumes(MediaType.APPLICATION_JSON )
	@Produces(MediaType.APPLICATION_JSON)
	public Response deconnexion(para send) 
	{   
		int salon=send.salon;
		String response = null;
		MyXmlRpcClient clientSS=null;
		
		
		switch (salon) {
		case 1:
			clientSS=new MyXmlRpcClient(this.salon1);
			break;
		case 2:
			clientSS=new MyXmlRpcClient(this.salon2);
			break;	

		case 3:
			clientSS=new MyXmlRpcClient(this.salon3);
			break;	
		default:
			break;
		}
		
		
	
		
		    String result=new String();
		    
		    
			try {
				result = clientSS.deconnexion(send.getName());
				response=result; 
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		      
			
		        
	     System.out.println("well done deconnexion!");
		return Response.ok(response).build(); 
	}
	
	
	@GET
	@Path("getNewMessage/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getNewMessage(@DefaultValue("1") @QueryParam("salon") int salon,@PathParam("id") String id) 
	{   
		
		
		String response = null;
		MyXmlRpcClient clientSS=null;
		
		switch (salon) {
		case 1:
			clientSS=new MyXmlRpcClient(this.salon1);
			break;
		case 2:
			clientSS=new MyXmlRpcClient(this.salon2);
			break;	

		case 3:
			clientSS=new MyXmlRpcClient(this.salon3);
			break;	
		default:
			break;
		}
		
		
		
		
		ObjectMapper jsonConvert = new ObjectMapper();
		    List<Message> result=null;
			try {
				result = clientSS.recupererMessage(id);
				response= jsonConvert.writeValueAsString(result);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		      
 
		      
		    
	     System.out.println("well done messget !!!");
		return Response.ok(response).build(); 
	}
	
	
	@GET
	@Path("getNewUser/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getNewUser(@DefaultValue("1") @QueryParam("salon") int salon,@PathParam("id") String id) 
	{   
		String response = null;
		MyXmlRpcClient clientSS=null;
		
		switch (salon) {
		case 1:
			clientSS=new MyXmlRpcClient(this.salon1);
			break;
		case 2:
			clientSS=new MyXmlRpcClient(this.salon2);
			break;	

		case 3:
			clientSS=new MyXmlRpcClient(this.salon3);
			break;	
		default:
			break;
		}
		
		
		
		ObjectMapper jsonConvert = new ObjectMapper();
		    List<String> result=null;
			try {
				result = clientSS.recupererUsers(id);
				response= jsonConvert.writeValueAsString(result);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		      
 
		      
		    
	    
		return Response.ok(response).build(); 
	}
	
	
	
	
}
