package org.esp.dic3.messenger.testsend;
import java.net.URI;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

public class Test {

    public static void main(String[] args) {
        ClientConfig config = new ClientConfig();

        Client client = ClientBuilder.newClient(config);

        WebTarget target = client.target(getBaseURI());

        String response ;
     
        para form=new para("badiane",1);
        response = target.path("message/inscription").request().post(Entity.entity(form,MediaType.APPLICATION_JSON),String.class);
        
        System.out.println(response);
        form.setMessage("Hello !!! ");
        response = target.path("message/postMessage").request().post(Entity.entity(form,MediaType.APPLICATION_JSON),String.class);
        
        System.out.println(response);
        
//        response = target.path("message/deconnecter").request().post(Entity.entity(form,MediaType.APPLICATION_JSON),String.class);
//        
//        System.out.println(response);
        
//      while(true)
//      {
//    	  response = target.path("message/getNewUser/"+form.getName()).queryParam("salon", 3).request().get(String.class);
//        if(!response.equals("null"))
//          System.out.println(response);
//        
//        response = target.path("message/getNewMessage/"+form.getName()).queryParam("salon", 3).request().get(String.class);
//        if(!response.equals("null"))
//          System.out.println(response);
//      }
      
        
    }

    private static URI getBaseURI() {
        return UriBuilder.fromUri("http://localhost:8082/messenger/webapi/").build();
    }
}