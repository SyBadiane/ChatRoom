package chatroom;

public class Message {
	 public Message(String pseudo,String texte) {
			
			
			this.texte = texte;
			this.pseudo = pseudo;
		}
	     
		 public String texte;	
	
	     public String pseudo;
}
