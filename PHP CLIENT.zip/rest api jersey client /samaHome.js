       pkiAppModule.controller('ToastCtrl', function($scope,$rootScope, $mdToast) {
      $scope.salonChoiceC=[];
      $scope.salonChoiceC[0]=$rootScope.salonChoice[0];
      $scope.salonChoiceC[1]=$rootScope.salonChoice[1];
      $scope.salonChoiceC[2]=$rootScope.salonChoice[2]; 


      $scope.message="Attention ! Veillez vous reconnecter en cliquant sur Salon"+$rootScope.salon;
      $scope.closeToast = function() {
        $mdToast
          .hide()
          .then(function() {
            isDlgOpen = false;
          });
      };
       });
       pkiAppModule.controller('homeCtrl', function($rootScope,$http,$interval,$scope, $mdToast) {
              $rootScope.pseudo=localStorage.getItem('pseudo');
              $rootScope.salon=localStorage.getItem('salon');
              $rootScope.messages=[];
              $rootScope.userMessages=[[],[],[]];
              $rootScope.users=[];
              $scope.deconnectS1=false;
              $scope.deconnectS2=false;
              $scope.deconnectS3=false;
              $scope.recherche="";
              $rootScope.salonConnect=[Number(localStorage.getItem('salon1')),Number(localStorage.getItem('salon2')),Number(localStorage.getItem('salon3'))];
                
              $rootScope.salonChoice=[false,false,false];
              $rootScope.onChange=false;
              loadUsers();
              loadMessages();

                 $interval(function () {
                  if(!$rootScope.onChange)   
                   { loadUsers();
                     loadMessages();
                    }
                }, 2000);
             
              $rootScope.change=function(num,S)
                {
                      $rootScope.salonChoice[num-1]=S;
                }
             $rootScope.deconnexion=function()
                {
                    $rootScope.onChange=true; 
                    if($rootScope.salonChoice[0])
                        {
                            deconnexion(1);
                            
                        }
                    if($rootScope.salonChoice[1])
                        {
                            deconnexion(2);
                             
                        }
                    if($rootScope.salonChoice[2])
                        {
                            deconnexion(3);
                            
                        }
                    if(!$rootScope.salonConnect[0] &&  !$rootScope.salonConnect[1] &&  !$rootScope.salonConnect[2])
                          window.location.assign('/index.php');

                     $rootScope.onChange=false;
                     
                };

                $rootScope.changeSalon=function(num)
                { 
                    if(num!=$rootScope.salon || (num==$rootScope.salon && !$rootScope.salonConnect[num-1]))
                    { 
                       $rootScope.onChange=true;
                      
                        if(!$rootScope.salonConnect[num-1])
                        { 
                            $rootScope.salonConnect[num-1]=1;
                            localStorage.setItem('salon'+num,true);
                            var data={"pseudo":$rootScope.pseudo,"salon":num};
                            var url = "/service.php";
                            var req = {
                                method: 'POST',
                                url: url,
                                data: $.param(data),
                                headers: {'Content-Type': 'application/x-www-form-urlencoded'}

                            };

                            $http(req)
                                .then(function (response) {
                                
                                var data = response.data;
                                if(data!="No data found")
                                {
                                    localStorage.setItem('pseudo',$rootScope.pseudo);
                                    localStorage.setItem('salon', $rootScope.salon);
                                
                                    localStorage.setItem('salon'+$rootScope.salon, 1);
                                    $rootScope.messages=[];
                                     
                                }   

                                });
                        }
                       
                        $rootScope.userMessages[$rootScope.salon-1]=$rootScope.messages;
                        $rootScope.messages=$rootScope.userMessages[num-1];
                         $rootScope.salon=num;
                         $rootScope.users=[];
                        $rootScope.onChange=false;
                            
                    }    
                };

              $rootScope.sendMessage=function(message)
                {   
                   
                   if($rootScope.salonConnect[$rootScope.salon-1])
                   {  
                        var data={"pseudo":$rootScope.pseudo,"message":message,"salon":$rootScope.salon};
                        var url = "/sendMess.php";
                        var req = {
                            method: 'POST',
                            url: url,
                            data: $.param(data),
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}

                        };

                        $http(req)
                            .then(function (response) {
                            
                                var data = response.data;
                            
                            if(data!="No data found")
                                {
                                $scope.message="";  
                                }

                            });
                   }
                    else
                    {
                        $mdToast.show({
                        hideDelay   : 3000,
                        position    : 'top center',
                        controller  : 'ToastCtrl',
                        templateUrl : 'alertNotconnected.html'
                        });

                    }      
                };

              function loadUsers(){
                 
               var data={"pseudo":$rootScope.pseudo,"salon":$rootScope.salon};
                var url = "/getUsers.php";
                var req = {
                    method: 'POST',
                    url: url,
                    data: $.param(data),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}

                };

                $http(req)
                    .then(function (response) {
                       
                        var data = response.data;
                        
                       if(data!="No data found" && data!="null")
                        {  
                            
                            $rootScope.users=data;
                        }

                    });
              }
              
               function loadMessages(){
               var data={"pseudo":$rootScope.pseudo,"salon":$rootScope.salon};
                var url = "/getMessages.php";
                var req = {
                    method: 'POST',
                    url: url,
                    data: $.param(data),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}

                };

                $http(req)
                    .then(function (response) {
                        
                        var data = response.data;
                        
                        if(data!="No data found" && data!="null")
                        {
                           
                            $rootScope.messages.push(data);
                        }

                    });
              }
              
              function deconnexion(salon)
              {
                  $rootScope.salonConnect[salon-1]=0;
                  localStorage.setItem('salon'+salon,0);

                   $mdToast.show({
                        hideDelay   : 3000,
                        position    : 'top right',
                        controller  : 'ToastCtrl',
                        templateUrl : 'notification.html'
                        });
                    
                 
                //    if(salon==$rootScope.salon)
                //     {
                //      $rootScope.messages=[]; 
                //       $rootScope.users=[];
                //     }
                     var data={"pseudo":$rootScope.pseudo,"salon":salon};
                    var url = "/logout.php";
                    var req = {
                        method: 'POST',
                        url: url,
                        data: $.param(data),
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'}

                    };

                    $http(req)
                        .then(function (response) {
                        
                            var data = response.data;
                           
                        if(data!="No data found")
                            {
                             $rootScope.salonChoice[salon-1]=false;
                            }

                        });
                        
              }

       });

      