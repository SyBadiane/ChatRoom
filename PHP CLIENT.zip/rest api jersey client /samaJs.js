	$(document).ready(function(){
    		$('.button-collapse').sideNav({
		      menuWidth: 300, // Default is 300
		      edge: 'left', // Choose the horizontal origin
		      closeOnClick: true, // Closes side-nav on <a> clicks, useful for Angular/Meteor
		      draggable: true, // Choose whether you can drag to open on touch screens,
		      onOpen: function(el) { /* Do Stuff*/ }, // A function to be called when sideNav is opened
		      onClose: function(el) { /* Do Stuff*/ }, // A function to be called when sideNav is closed
		    }
		  );
              $('.parallax').parallax();
              $('select').material_select();
              

         
           


        });


         var pkiAppModule= angular.module('BlankApp', []);



      
           
           pkiAppModule.controller('loginCtrl', function($rootScope,$http) {
            $rootScope.error=false;
            $rootScope.change=function()
            {
                   $rootScope.error=false;
            }
      $rootScope.login=function(pseudo,salon){
                $rootScope.pseudo=pseudo;
                var data={"pseudo":pseudo,"salon":salon};
                var url = "/service.php";
                var req = {
                    method: 'POST',
                    url: url,
                    data: $.param(data),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}

                };

                $http(req)
                    .then(function (response) {
                       
                        var data = response.data;
                       console.log(data);
                  if(data!="No data found")
                    {
                      if(data==="user already existed")
                      {
                        $rootScope.error=true;

                      }    
                      else
                    {
                      localStorage.setItem('pseudo', pseudo);
                      localStorage.setItem('salon', salon);
                      localStorage.setItem('salon1', 0);
                      localStorage.setItem('salon2', 0);
                      localStorage.setItem('salon3', 0);

                      localStorage.setItem('salon'+salon, 1);
                       window.location.assign('/home.php');
                    }
                    }   

                    });
      };  


    //    pkiAppModule.controller('loginCtrl', function($rootScope,$http) {

    //           alert($rootScope.form.pseudo);
    //    });

           });