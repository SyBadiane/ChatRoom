<?php


$data= array("name"=>$_POST['pseudo'],"message"=>$_POST['message'],"salon"=>(int)$_POST['salon']);
$data=json_encode($data);
$url2 ="http://localhost:8082/messenger/webapi/message/postMessage";

 $response = file_get_contents($url2, null, stream_context_create(array(
 'http' => array(
 'method' => 'POST',
 'header' => 'Content-Type: application/json' . "\r\n"
 . 'Content-Length: ' . strlen($data) . "\r\n",
 'content' => $data,
 ),
 ))); 


 if(!empty($response))
{

echo $response;

}
else
{
echo "No data found"; 
} 

?>