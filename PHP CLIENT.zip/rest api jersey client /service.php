<?php

//no jar files required
$url ="http://localhost:8082/messenger/webapi/message/inscription";

// $data= array("name"=>"Diouf","email:"=>"badiane04@gamil.com","CODE"=>111,"message"=>"Don't need it !!!");

// $data= array("name"=>"Aby","email:"=>"badiane04@gamil.com","CODE"=>111,"message"=>"Salam tout le monde !");



$data= array("name"=>$_POST['pseudo'],"salon"=>(int)$_POST['salon']);
    
$data=json_encode($data);

$response = file_get_contents($url, null, stream_context_create(array(
'http' => array(
'method' => 'POST',
'header' => 'Content-Type: application/json' . "\r\n"
. 'Content-Length: ' . strlen($data) . "\r\n",
'content' => $data,
),
)));

// $url2 ="http://localhost:8082/messenger/webapi/message/postMessage";
// $response2 = file_get_contents($url2, null, stream_context_create(array(
// 'http' => array(
// 'method' => 'POST',
// 'header' => 'Content-Type: application/json' . "\r\n"
// . 'Content-Length: ' . strlen($data) . "\r\n",
// 'content' => $data,
// ),
// )));

// $url3 ="http://localhost:8082/messenger/webapi/message/getNewMessage/"+$data["name"];
// $response3 = file_get_contents($url3, null, stream_context_create(array(
// 'http' => array(
// 'method' => 'GET',
// 'header' => 'Content-Type: application/json',
// ),
// )));

if(!empty($response))
{

echo $response;

}
else
{
echo "No data found"; 
} 

?>
