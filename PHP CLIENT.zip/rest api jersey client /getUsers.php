<?php

$data= array("name"=>$_POST['pseudo'],"salon"=>(int)$_POST['salon']);
   
$url3 ="http://localhost:8082/messenger/webapi/message/getNewUser/".$data["name"]."?salon=".$data["salon"];
$response = file_get_contents($url3, null, stream_context_create(array(
'http' => array(
'method' => 'GET',
'header' => 'Content-Type: application/json',
),
)));

if(!empty($response))
{

echo $response;

}
else
{
echo "No data found"; 
} 

?>
