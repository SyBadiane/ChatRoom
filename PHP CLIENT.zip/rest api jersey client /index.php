
<!DOCTYPE html>
<html lang="en" ng-app="BlankApp" ng-cloak>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="https://cdn3.iconfinder.com/data/icons/happily-colored-snlogo/128/medium.png">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <title>Login!</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" href="style.css">
    
  </head>
  <body >
    <nav class="grey darken-4">
	    <div class="nav-wrapper">
		    <a href="#!" class="brand-logo center"><img src="https://cdn3.iconfinder.com/data/icons/happily-colored-snlogo/128/medium.png"></a>
		    <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
		    <!-- <ul class="right hide-on-med-and-down">
				<li><a href="#">Inicio</a></li>
		        <li><a href="#">Trabajos</a></li>
		        <li><a href="#">Redes</a></li>
		        <li><a href="#">Contactos</a></li>
		    </ul>
		    <ul class="side-nav" id="mobile-demo">
		        <li><a href="#">Inicio</a></li>
		        <li><a href="#">Trabajos</a></li>
		        <li><a href="#">Redes</a></li>
		        <li><a href="#">Contactos</a></li>
		    </ul> -->
		</div>
  	</nav>
	<div class="had-container">

	     <div class="parallax-container logueo">
      	<div class="parallax"><img src="https://alistapart.com/d/438/fig-6--background-blend-mode.jpg"></div>
      	<div class="row"><br>
      		<div class="col m8 s8 offset-m2 offset-s2 center" style="margin-top: -20px;">
      			<h4 class="truncate bg-card-user" style="height: 614px;">
      				<img src="https://cdn3.iconfinder.com/data/icons/happily-colored-snlogo/128/medium.png" alt="" class="circle responsive-img">
					  <div class="row login" ng-controller="loginCtrl" style="height:400px;">
					  	<h4 style="margin-bottom: -4px;">SUNU CHAT</h4>
							<small style="font-size: 50%;color: red;" ng-if="error">Attention ! Le Pseudonyme {{pseudo}} n'est pas disponible.</small>
					    <form class="col s12">
					      <div class="row">
					         <div class="input-field col m12 s12">
					          <i class="material-icons iconis prefix">account_box</i>
					          <input id="icon_prefix" ng-change="change()" ng-model="pseudo"  type="text" class="validate">
					          <label for="icon_prefix">Pseudonyme</label>
					        </div>
					      </div>
					      <div class="row">
					        <div class="input-field col m1 s1">
					          <i class="material-icons iconis">enhanced_encryption</i>
                            </div>
                             <div class="col m11 s11"> 
                                    <select class="icons" ng-model="salon" id="salon">
                                    <option value="0" disabled selected>Choisir votre salon</option>
                                    <option value="1" data-icon="whatsap.png" class="circle">Salon 1</option>
                                    <option value="2" data-icon="snap.png" class="circle">Salon 2</option>
                                    <option value="3" data-icon="messenger.png" class="circle">Salon 3</option>
                                    </select>
					        </div>
					      </div>
					      <div class="row" style="margin-top: 40px;">
					      	<button class="btn waves-effect waves-light" ng-click="login(pseudo,salon)" type="submit" name="action">CONNEXION</button>
					      </div>
					    </form>
					  </div>
      			</h4>
		   	  </div>
	    	</div>
	    </div>
    </div>
    

    </div> <!-- fin del .container -->

<footer class="page-footer grey darken-4" style="padding:0px;margin:0;">
    <div class="footer-copyright">
        <div class="container center">
        	Copyright © 2018 - DIC3-TELE-INFO
        </div>
    </div>
</footer>
     
    <!-- jQuery first, then Bootstrap JS. -->
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular.min.js"></script> 

    <script src="samaJs.js"></script>
  </body>
</html>