import java.util.ArrayList;
import java.util.List;

import org.apache.xmlrpc.webserver.ServletWebServer;
import org.apache.xmlrpc.webserver.XmlRpcServlet;

public class XmlRpcServer {
	
	
	 
	public static void main(String[] args) throws Exception {
		XmlRpcServlet servlet = new XmlRpcServlet();
        ServletWebServer webServer = new ServletWebServer(servlet, 8010);
        
        webServer.start();		
		System.out.println("SALON-1: XML-RPC Server running...");
	}
	
   
}