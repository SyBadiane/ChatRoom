import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.servlet.ServletException;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import org.apache.xmlrpc.webserver.ServletWebServer;
import org.apache.xmlrpc.webserver.XmlRpcServlet;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
public class InterfaceSalon1 extends JFrame {

	private JPanel contentPane;
	private JTextField port;
	private JTextArea ecran;
	

	/**
	 * Launch the application.
	 * @throws IOException 
	 * @throws ServletException 
	 */
	
	
	public String runServer(String port) throws IOException, ServletException 
	{
		XmlRpcServlet servlet = new XmlRpcServlet();
        ServletWebServer webServer = new ServletWebServer(servlet, Integer.parseInt(port));
        
        webServer.start();	
        
        return "done";
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					InterfaceSalon1 frame = new InterfaceSalon1();
					
					
				try 
				{	
					frame.runServer("8000");	
			        frame.ecran.setText("SALON-1: Le serveur XML-RPC a bien demarré...");
					
				}
				catch (Exception ex)
				{
					frame.ecran.setText("Erreur de demarrage du serveur.Veuillez changer de port ! ");
				}
					
					
					frame.setVisible(true);
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InterfaceSalon1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		ecran = new JTextArea();
		ecran.setText("Salon 1");
		ecran.setBounds(20, 61, 411, 118);
		contentPane.add(ecran);
		
		port = new JTextField();
		port.setText("8000");
		port.setBounds(28, 213, 185, 48);
		contentPane.add(port);
		port.setColumns(10);
		
		JButton btnNewButton = new JButton("Valider");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 try {
					runServer(port.getText());
					ecran.setText("SALON-1: Le serveur XML-RPC a bien demarré...");
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					ecran.setText("Erreur de demarrage du serveur.Veuillez changer de port ! ");
				} 
			}
		});
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.setBackground(Color.BLUE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnNewButton.setBounds(270, 220, 117, 37);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Quitter");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setBounds(284, 6, 117, 29);
		contentPane.add(btnNewButton_1);
	}
}
