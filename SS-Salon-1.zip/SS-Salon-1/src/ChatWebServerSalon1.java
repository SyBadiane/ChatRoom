import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.*;

public class ChatWebServerSalon1 {

	protected static Logger logger = Logger.getLogger("defaultPakage.ChatWebServer");

	private static Handler fh;
	private static List<String> connected = new ArrayList<String>();
	private static List<Connected> connectedM = new ArrayList<Connected>();
	private static List<MessageList> messages = new ArrayList<MessageList>();
	private static int numMessage;
	private static  boolean firsTime=true;

	public ChatWebServerSalon1() {
		try {
			if (this.firsTime) {
				// suppress the logging output to the console

				logger.setUseParentHandlers(false);

				fh = new FileHandler("myLog.log", true);
				fh.setFormatter(new SimpleFormatter());
				logger.addHandler(fh);
				logger.setLevel(Level.ALL);
			}
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

	}

	public String subscribe(String pseudo) {
		if (!connected.contains(pseudo)) {
		try {
			System.out.println(pseudo + " vient de se connecter");
			this.connected.add(pseudo);
			this.connectedM.add(new Connected(pseudo, 0));
			logger.info(pseudo + " vient de se connecter");
			 this.firsTime=false;
			return "Vous venez de vous connecter ";
		} catch (Exception e) {
			return "error connexion";
		}
		
		}
		else
			return "user already existed";
	}

	public String unsubscribe(String pseudo) {

		try {

			System.out.println(pseudo + " vient de se deconnecter");
			sendMessage( pseudo, "vient de partir");
			this.connected.remove(pseudo);
			logger.info(pseudo + " vient de se deconnecter");
			return (new String("Vous venez de vous deconnecter "));
		} catch (Exception e) {
			return "error deconnexion";
		}

	}

	public String sendMessage(String pseudo, String message) {

		try {
			if (connected.contains(pseudo)) {
				this.numMessage += 1;
				this.messages.add(new MessageList(this.numMessage, new Message(pseudo, message), 0));
				Object[] params = new Object[] { pseudo, message };
				logger.logp(Level.INFO, "ChatWebServer", "sendMessage ", pseudo + " " + message, params);

				return "[" + pseudo + "]: " + message;
			} else
				return (new String("Vous n'êtes pas connecté"));
		} catch (Exception e) {
			return "error envoie de message";
		}

	}

	public String[][] newMessages(String pseudo) {

		if (connected.contains(pseudo)) {
			int i = 0;
			int size = this.connectedM.size();
			Connected userC = new Connected();
			MessageList messageC;

			// on cherche l'utilisateur qui veut voir les derniers messages
			while (i < size && !this.connectedM.get(i).pseudo.equals(pseudo))
				i += 1;

			// on l'a retrouve on le recupere dans userC
			if (i != size)
				userC = this.connectedM.get(i);

			// on verifie la position du dernier message qu'il a lu
			if (userC.numeroMessage == 0)
				i = this.numMessage;
			else
				i = this.numMessage - userC.numeroMessage;

			// les messages non lu
			String[] messageCu = new String[i];

			// les expediteurs de ces messages
			String[] userCu = new String[i];
			int j = 0;
			int numNextMessage = userC.numeroMessage + 1;

			// on verifie s'il n'a pas tout lu.
			if (numNextMessage <= this.numMessage) {

				for (int k = 0; k < this.messages.size(); k++) {
					messageC = this.messages.get(k);
					if (messageC.numero >= numNextMessage) {
						messageCu[j] = messageC.message.texte;
						userCu[j] = messageC.message.pseudo;
						j += 1;
						messageC.nombreVu += 1;
						userC.numeroMessage = messageC.numero;
					}

					
				}
			}

			String[][] resultat = { userCu, messageCu };

			return resultat;
		} else
			return new String[0][0];
	}
	
	
	public List<String> newUsers(String pseudo) {
		
		if (connected.contains(pseudo)) {
			
			return this.connected;
			
//			int i = 0;
//			int size = this.connectedM.size();
//			Connected userC = new Connected();
//			List<String> usersC=null;
//
//			// on cherche l'utilisateur qui veut voir les derniers messages
//			while (i < size && !this.connectedM.get(i).pseudo.equals(pseudo))
//				i += 1;
//
//			// on l'a retrouve on le recupere dans userC
//			if (i != size)
//				userC = this.connectedM.get(i);
//            
//			
//			
//			usersC=connected.subList(userC.numeroUser,size);
//			
//			if(usersC!=null) 
//			{ 
//			   userC.numeroUser=	size;
//			   return usersC;
//			}
//			 else
//				return null;
//				
			
			
			
		}
		return new ArrayList<String>();
	}
	

	class Connected {

		public Connected() {
		}

		public Connected(String pseudo, Integer num) {
			this.pseudo = pseudo;
			this.numeroMessage = num;
			this.numeroUser=num;
		}

		public String pseudo;
		public Integer numeroMessage;
        public Integer numeroUser;
		
	}

	class Message {
		public Message(String pseudo, String texte) {

			this.texte = texte;
			this.pseudo = pseudo;
		}

		public String texte;

		public String pseudo;
	}

	class MessageList {

		public MessageList(Integer numero, Message message, Integer nombreVu) {

			this.numero = numero;
			this.message = message;
			this.nombreVu = nombreVu;

		}

		public Integer numero;
		public Message message;
		public Integer nombreVu;

	}
}
